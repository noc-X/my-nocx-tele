import React from 'react';

const WalletConnect: React.FC = () => {
  return (
    <div>
      <h2>Wallet Connect</h2>
      <p>Connect your wallet to access features.</p>
      <button>Connect Wallet</button>

      
    </div>
  );
};

export default WalletConnect;
